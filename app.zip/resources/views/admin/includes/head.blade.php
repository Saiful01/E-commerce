<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
<title>Admin- Home</title>
<meta content="Admin Dashboard" name="description">
<meta content="Themesbrand" name="author">
<link rel="shortcut icon" href="/admin/assets/images/favicon.ico">
<link rel="stylesheet" href="/admin/plugins/morris/morris.css">
<link href="/admin/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="/admin/assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
<link href="/admin/assets/css/icons.css" rel="stylesheet" type="text/css">
<link href="/admin/assets/css/style.css" rel="stylesheet" type="text/css">

<link href="/admin/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="/admin/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">
<!-- Responsive datatable examples -->
<link href="/admin/plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="/admin/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="/admin/assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
<link href="/admin/assets/css/icons.css" rel="stylesheet" type="text/css">
<link href="/admin/assets/css/style.css" rel="stylesheet" type="text/css">