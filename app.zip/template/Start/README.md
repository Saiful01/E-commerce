Responsive Sidebar Navigation
=========

An easy-to-integrate side, vertical navigation, ideal for dashboards and admin areas.

[Article on CodyHouse](http://codyhouse.co/?p=881)

[Demo](http://codyhouse.co/demo/responsive-sidebar-navigation/index.html)
 
[Terms](http://codyhouse.co/terms/)

Icons: [Nucleo Library](https://nucleoapp.com/)

Diagonal movement plugin: [jQuery-menu-aim](https://github.com/kamens/jQuery-menu-aim)
