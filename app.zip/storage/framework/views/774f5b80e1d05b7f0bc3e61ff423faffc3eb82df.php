<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin.includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body><!-- Begin page -->
<div id="wrapper"><!-- Top Bar Start -->
    <?php echo $__env->make('admin.includes.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.includes.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <div class="content-page"><!-- Start content -->
        <div class="content">
            <div class="container-fluid">


                <?php echo $__env->yieldContent('content'); ?>


            </div><!-- container-fluid -->
        </div><!-- content -->
        <footer class="footer">
            © 2020 PixonLab - <span class="d-none d-sm-inline-block">Crafted with <i
                        class="mdi mdi-heart text-danger"></i> by PixonLab</span>.
        </footer>
    </div>

</div><!-- END wrapper --><!-- jQuery  -->
<?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>