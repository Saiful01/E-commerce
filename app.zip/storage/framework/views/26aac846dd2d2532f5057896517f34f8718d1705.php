<br>
<div class="categories">
    <div class="container">

        <div class="card">
            <div class="col-md-3">
                <h5>ক্যাটেগরি</h5>
                <hr class="horizontal-line">
            </div>


            <div class="card-body">
                <div class="row">
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-2" style="padding-bottom: 15px;">
                            <a href="/product/category/<?php echo e($category->category_id); ?>">
                                <img class="img-thumbnail category-img" ng-src="/images/category/<?php echo e($category->category_image); ?>" height="100px">
                                <p class="card-title product-title"><?php echo e($category->category_name); ?></p>
                            </a>
                        </div>

                        <?php if($i>=18): ?>
                            <?php break; ?>
                        <?php endif; ?>

                        <?php ($i++); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>


        </div>

    </div>
</div>
