<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box"><h4 class="page-title">Confirmed Orders</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Product</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Show</a></li>
                </ol>
            </div>
        </div>
    </div><!-- end row -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-20">
                <div class="card-body">

                    <form class="form-inline" method="post" action="/admin/sell/show" enctype="multipart/form-data">

                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">From</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="date" name="from" required>
                                <input class="form-control" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">To</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="date" name="to" required>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label"></label>
                            <div class="col-sm-10">
                                <button type="submit" class="btn btn-primary waves-effect waves-light">Search</button>
                            </div>
                        </div>

                    </form>


                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-20">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('success')); ?>!</strong>
                    </div>
                <?php endif; ?>
                <?php if(session('failed')): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('failed')); ?>!</strong>
                    </div>
                <?php endif; ?>


                <div class="card-body" id="printableArea">
                    <h4 class="mt-0 header-title">Product
                        <button class="btn btn-sm btn-primary pull-right"
                                onclick="printDiv('printableArea')">Print
                        </button>
                    </h4>
                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Subtotal</th>
                            <th>Shipping</th>
                            <th>Discount</th>
                            <th>Paid</th>
                            <th>Total</th>
                            <th>Due</th>
                            <th>Status</th>
                            <th>Order time</th>
                            <th>City</th>
                            <th>Address</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php ($i=1); ?>
                        <?php ($total=0); ?>
                        <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($total=$total+$sell->sub_total_price); ?>
                            <tr>
                                <th scope="row"><?php echo e($i++); ?></th>
                                <td><?php echo e($sell->customer_name); ?></td>
                                <td><?php echo e($sell->customer_phone); ?></td>

                                <td><?php echo e($sell->sub_total_price); ?></td>
                                <td><?php echo e($sell->shipping_cost); ?></td>
                                <td>
                                    <?php if($sell->discount<=0): ?>
                                        <button type="button" class="btn btn-sm btn-info" data-toggle="modal"
                                                data-target="#myModal<?php echo e($i); ?>">Discount
                                        </button> <?php else: ?> <?php echo e($sell->discount); ?>

                                <?php endif; ?>


                                <!-- Modal -->
                                    <div id="myModal<?php echo e($i); ?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-body">
                                                    <form method="post" action="/admin/product/discount"
                                                          enctype="multipart/form-data">

                                                        <div class="form-group row" style="display: none">

                                                            <div class="col-sm-10">
                                                                <input class="form-control" type="hidden" name="_token"
                                                                       value="<?php echo e(csrf_token()); ?>">
                                                                <input class="form-control" type="text" name="invoice"
                                                                       value="<?php echo e($sell->sell_invoice); ?>">

                                                            </div>
                                                        </div>

                                                        <div class="form-group row">
                                                            <label for="example-text-input"
                                                                   class="col-sm-3 col-form-label">Total
                                                                Discount</label>
                                                            <div class="col-sm-9">
                                                                <input class="form-control" type="number"
                                                                       name="discount"
                                                                       value="0">

                                                            </div>
                                                        </div>

                                                        <div class="form-group row">
                                                            <label class="col-sm-3 col-form-label"></label>
                                                            <div class="col-sm-9">
                                                                <button type="submit"
                                                                        class="btn btn-primary waves-effect waves-light">
                                                                    Submit
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </form>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">
                                                        Close
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </td>
                                <td>
                                    <?php if(($sell->total-$sell->discount) >= $sell->paid_amount): ?>
                                        <button type="button" class="btn btn-sm btn-info" data-toggle="modal"
                                                data-target="#PaymentModal<?php echo e($i); ?>">Pay
                                        </button>
                                        <?php echo e($sell->paid_amount); ?>

                                    <?php else: ?>
                                        <span class="badge badge-pill badge-success">Paid</span>
                                <?php endif; ?>


                                <!-- Modal -->
                                    <div id="PaymentModal<?php echo e($i); ?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-body">
                                                    <p>Already paid <?php echo e($sell->paid_amount); ?></p>
                                                    <p>New paid amount will be added with previous amount.</p>
                                                    <form method="post" action="/admin/product/pay"
                                                          enctype="multipart/form-data">

                                                        <div class="form-group row" style="display: none">

                                                            <div class="col-sm-10">
                                                                <input class="form-control" type="hidden" name="_token"
                                                                       value="<?php echo e(csrf_token()); ?>">
                                                                <input class="form-control" type="text" name="invoice"
                                                                       value="<?php echo e($sell->sell_invoice); ?>">

                                                            </div>
                                                        </div>

                                                        <div class="form-group row">
                                                            <label for="example-text-input"
                                                                   class="col-sm-3 col-form-label">Payment</label>
                                                            <div class="col-sm-9">
                                                                <input class="form-control" type="number"
                                                                       name="paid_amount" value="0">

                                                            </div>
                                                        </div>

                                                        <div class="form-group row">
                                                            <label class="col-sm-3 col-form-label"></label>
                                                            <div class="col-sm-9">
                                                                <button type="submit"
                                                                        class="btn btn-primary waves-effect waves-light">
                                                                    Submit
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </form>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">
                                                        Close
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </td>
                                <td><?php echo e($sell->total-$sell->discount); ?></td>
                                <td><?php echo e(($sell->total-$sell->discount)-($sell->paid_amount)); ?></td>

                                <td><?php if($sell->delivery_status==0): ?> <span
                                            class="badge badge-pill badge-warning">Pending</span> <?php elseif($sell->delivery_status==1): ?>
                                        <span class="badge badge-pill badge-info">Confirm</span> <?php elseif($sell->delivery_status==2): ?>
                                        <span class="badge badge-pill badge-success">Relaese</span> <?php elseif($sell->delivery_status==3): ?>
                                        <span class="badge badge-pill badge-danger">Received</span> <?php else: ?>
                                        <span class="badge badge-pill badge-danger">Cancel</span>
                                    <?php endif; ?></td>
                                <td><?php echo e($sell->created_at); ?></td>
                                <td><?php echo e($sell->customer_city); ?></td>
                                <td><?php echo e($sell->customer_address1); ?></td>

                                <td>
                                    <div class="btn-group m-b-10">
                                        <button type="button" class="btn btn-info dropdown-toggle"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action
                                        </button>
                                        <div class="dropdown-menu" x-placement="bottom-start"
                                             style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 33px, 0px);">
                                            <a class="dropdown-item"
                                               href="/admin/product/delivery/<?php echo e($sell->sell_invoice); ?>"
                                               onclick="return confirm('Are you sure?');">Release</a>
                                            <a class="dropdown-item"
                                               href="/admin/product/received/<?php echo e($sell->sell_invoice); ?>"
                                               onclick="return confirm('Are you sure?');">Received</a>
                                            <?php if(Session::get('user_type')==1): ?>
                                                <a class="dropdown-item"
                                                   href="/admin/product/cancel/<?php echo e($sell->sell_invoice); ?>"
                                                   onclick="return confirm('Are you sure?');">Cancel</a>
                                            <?php endif; ?>
                                            <a class="dropdown-item"
                                               href="/admin/product/details/<?php echo e($sell->sell_invoice); ?>">Details</a>

                                        </div>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <p style="display: none"><?php echo e($total); ?></p>
                        </tbody>
                    </table>
                </div>
                

            </div>
        </div>
    </div>


    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>