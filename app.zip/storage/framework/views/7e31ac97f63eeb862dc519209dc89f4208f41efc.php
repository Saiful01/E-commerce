<?php $__env->startSection('content'); ?>

    <style>
        p, h6, td, th {
            font-size: 17px;
            line-height: 20px;
        }
    </style>
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box"><h4 class="page-title">Product</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Product</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Show</a></li>
                </ol>
            </div>
        </div>
    </div><!-- end row -->
    <form method="post" action="/admin/extra-product/store" enctype="multipart/form-data">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo e(session('success')); ?>!</strong>
            </div>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <div class="alert alert-danger alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo e(session('failed')); ?>!</strong>
            </div>
        <?php endif; ?>
        <div class="row">

            <div class="col-md-3">
                <div class="form-group row">
                    <label for="example-text-input" class="col-sm-2 col-form-label">Product Name</label>
                    <div class="form-group col-sm-10">
                        <input class="form-control" type="text" name="product_name" required>
                        <input class="form-control" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input class="form-control" type="hidden" name="sell_invoice" value="<?php echo e($customer->sell_invoice); ?>">

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group row">
                    <label for="example-text-input" class="col-sm-2 col-form-label">Product Unit</label>
                    <div class="form-group col-sm-10">
                        <input class="form-control" type="text" name="quantity" required>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group row">
                    <label for="example-text-input" class="col-sm-2 col-form-label">Unit Price</label>
                    <div class="form-group col-sm-10">
                        <input class="form-control" type="text" name="selling_price" required>

                    </div>
                </div>
            </div>
            <div class="col-md-1">
                <div class="form-group row">

                    <button type="submit" class="form-control btn-primary">Save</button>

                </div>
            </div>
        </div>

    </form>


    <div class="row">
        <div class="col-lg-12">
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary waves-effect waves-light"
                        onclick="printDiv('printableArea')">Print
                </button>
            </div>
            <div class="card m-b-20">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('success')); ?>!</strong>
                    </div>
                <?php endif; ?>
                <?php if(session('failed')): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('failed')); ?>!</strong>
                    </div>
                <?php endif; ?>

                <div class="card-body" id="printableArea" style="margin-top: -15px;">
                    <div class="row">
                        <div class="col-md-4">

                            <p>
                                কেনারহাট<br>
                                শেখ হাসিনা সফটওয়্যার টেকনোলজি পার্ক,<br> এমটি ভবন,৬ষ্ঠ তলা, যশোর।<br>
                                হটলাইন: ০১৮৮০-০৬০৯০৯ <br>
                                www.kenarhat.com
                            </p>
                        </div>

                        <div class="col-md-4" style="text-align: center">
                            <img class="img-thumbnail" style="height: 112px;margin-bottom: 4px"
                                 src="/ecommerce/img/theme_logo.jpg"/>
                            <p style="font-size: 12px;">তারুণ্যের নিরাপদ খাদ্য আন্দোলন...</p>
                        </div>

                        <div class="col-md-4">
                            <h6><strong>নাম: <?php echo e($customer->customer_name); ?><br>
                                    ফোন: <?php echo e($customer->customer_phone); ?><br>
                                    ঠিকানা: <?php echo e($customer->customer_address2); ?><br>
                                    </strong></h6>
                        </div>


                    </div>
                    <br>
                    <table class="table mb-0 table-bordered invoice">
                        <thead>
                        <tr>
                            <th style="padding-top: 5px;padding-bottom: 5px;text-align: right; color: black">
                                #
                            </th>
                            <th style="padding-top: 5px;padding-bottom: 5px;text-align: right; color: black">
                                নাম
                            </th>
                            <th style="padding-top: 5px;padding-bottom: 5px;text-align: right; color: black">
                                ইউনিট
                            </th>
                            <th style="padding-top: 5px;padding-bottom: 5px;text-align: right; color: black">
                                পরিমাণ
                            </th>
                            <th style="padding-top: 5px;padding-bottom: 5px;text-align: right; color: black">
                                ইউনিট প্রাইস
                            </th>

                            <th style="padding-top: 5px;padding-bottom: 5px;text-align:right; color: black">
                                মোট দাম
                            </th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php ($i=1); ?>
                        <?php ($sub_total=0); ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black"><?php echo e($i++); ?></td>
                                <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black"><?php echo e($product->product_name); ?></td>

                                <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black">
                                    <?php echo e($product->product_measurement); ?>


                                </td>
                                <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black"><?php echo e($product->quantity); ?>

                                    টি
                                </td>
                                <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black"><?php echo e($product->selling_price); ?>

                                    টাকা/ <span
                                        style="text-decoration: line-through;"> <?php echo e($product->regular_price); ?>

                                        টাকা</span></td>
                                <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black"><?php echo e($product->total_price); ?>

                                    টাকা
                                </td>

                            </tr>

                            <?php ($sub_total=$sub_total+$product->total); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>

                    <div class="row">
                        <div class="col-md-4">
                            <br>
                            <br>
                            <img class="img-thumbnail" style="height: 90px;" src="/ecommerce/img/kenarhat_qr.png"/>
                        </div>
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                            <table style="width: 100%">
                                <tfoot class='table table-bordered' style="border: none">

                                <tr>

                                    <th style="padding-top: 5px;padding-bottom: 5px;color: black" colspan="2">শিপিং
                                        খরচ
                                    </th>
                                    <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black"><?php echo e($customer->shipping_cost); ?>

                                        টাকা
                                    </td>
                                </tr>

                                <tr>

                                    <th colspan="2" style="padding-top: 5px;padding-bottom: 5px">মোট
                                    </th>
                                    <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black"><?php echo e($customer->sub_total_price+$customer->shipping_cost); ?>

                                        টাকা
                                    </td>
                                </tr>

                                <tr>

                                    <th style="padding-top: 5px;padding-bottom: 5px;color: black" colspan="2">ছাড়</th>
                                    <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black"><?php echo e($customer->discount); ?>

                                        টাকা
                                    </td>
                                </tr>
                                <tr>

                                    <th style="padding-top: 5px;padding-bottom: 5px;color: black" colspan="2">অগ্রিম
                                    </th>
                                    <td style="padding-top: 5px;padding-bottom: 5px;text-align: right;color: black"><?php echo e($customer->paid_amount); ?>

                                        টাকা
                                    </td>
                                </tr>
                                <tr>

                                    <th style="padding-top: 5px;padding-bottom: 5px;color: black" colspan="2"><h6>
                                            <strong>সর্বমোট</strong></h6></th>
                                    <td style="padding-top: 1px;padding-bottom: 1px;text-align: right;color: black"><h6>
                                            <strong><?php echo e($customer->sub_total_price+$customer->shipping_cost-$customer->discount-$customer->paid_amount); ?>

                                                টাকা</strong>
                                        </h6></td>
                                </tr>

                                </tfoot>
                            </table>
                        </div>
                    </div>
                    Invoice ID: <strong>#<?php echo e($customer->sell_invoice); ?></strong>, <?php echo e(date('M m, Y H:i:s')); ?>

                    (<?php echo e(Session::get('name')); ?> )
                </div>
            </div>
        </div>
    </div>



    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>