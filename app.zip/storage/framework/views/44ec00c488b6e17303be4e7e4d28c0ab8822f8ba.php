<?php $__env->startSection('title', 'কেনারহাট'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('ecommerce.pages.home.slide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('ecommerce.pages.home.product_row', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('ecommerce.pages.home.category_row', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('ecommerce.pages.home.new_product_row', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('ecommerce.pages.home.shipping', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('ecommerce.pages.home.universal_cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>