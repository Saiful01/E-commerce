<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box"><h4 class="page-title">Product</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Product</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Show</a></li>
                </ol>
            </div>
        </div>
    </div><!-- end row -->


    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-20">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('success')); ?>!</strong>
                    </div>
                <?php endif; ?>
                <?php if(session('failed')): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('failed')); ?>!</strong>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <h4 class="mt-0 header-title">Product</h4>
                    <table class="table mb-0">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Product Name</th>
                            <th>Regular price</th>
                            <th>Selling price</th>
                            <th>Measurement</th>
                            <th>Category name</th>
                            <th>Keywords</th>
                            <th>Publish</th>
                            <th>Featured</th>
                            <th>Action</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($i++); ?></th>
                                <td><?php echo e($product->product_name); ?></td>
                                <td><?php echo e($product->regular_price); ?></td>
                                <td><?php echo e($product->selling_price); ?></td>
                                <td><?php echo e($product->product_measurement); ?></td>
                                <td><?php echo e($product->category_name); ?></td>
                                <td><?php echo e($product->keywords); ?></td>
                                <td>
                                    <?php if($product->publish_status==1): ?>
                                        <span class="badge badge-pill badge-info">Published</span>
                                    <?php else: ?>
                                        <span class="badge badge-pill badge-danger">Unpublished</span>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($product->featured_product==1): ?>
                                        <span class="badge badge-pill badge-info">Yes</span>
                                    <?php else: ?>
                                        <span class="badge badge-pill badge-danger">No</span>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group m-b-10">
                                        <button type="button" class="btn btn-info dropdown-toggle"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action
                                        </button>
                                        <div class="dropdown-menu" x-placement="bottom-start"
                                             style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 33px, 0px);">
                                            <a class="dropdown-item"
                                               href="/admin/product/edit/<?php echo e($product->product_id); ?>">Edit</a>
                                            <a class="dropdown-item"
                                               href="/admin/product/delete/<?php echo e($product->product_id); ?>">Delete</a>
                                            <?php if($product->publish_status==1): ?>
                                                <a class="dropdown-item"
                                                   href="/admin/product/unpublish/<?php echo e($product->product_id); ?>">Unpublish</a>
                                            <?php else: ?>
                                                <a class="dropdown-item"
                                                   href="/admin/product/publish/<?php echo e($product->product_id); ?>">Publish</a>

                                            <?php endif; ?>

                                            <?php if($product->featured_product==1): ?>
                                                <a class="dropdown-item"
                                                   href="/admin/product/feature-remove/<?php echo e($product->product_id); ?>">Remove Featured</a>
                                            <?php else: ?>
                                                <a class="dropdown-item"
                                                   href="/admin/product/feature/<?php echo e($product->product_id); ?>">Featured</a>

                                            <?php endif; ?>


                                        </div>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                    <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>